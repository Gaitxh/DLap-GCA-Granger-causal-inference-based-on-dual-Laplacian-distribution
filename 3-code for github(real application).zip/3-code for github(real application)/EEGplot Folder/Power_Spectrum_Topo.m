function Power_Spectrum_Topo(Data,Fs,freband)
H = figure('color',[1 1 1]);
for ch_i = 1:size(Data,1)
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    subplot(3,5,ch_i);
    plot(f,Pxx);
end
end