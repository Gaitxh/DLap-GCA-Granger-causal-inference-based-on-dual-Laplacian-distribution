function Brain_Topo_Emotion(Data,FilePath_Brain_Topo,Fs,low_c,high_c)
bandLimit = [low_c,high_c];
winlen = 64*(fix(size(Data,2)/64)-1);
Right_Hand = 0;Left_Hand = 0;
for elecOrder = 3:3
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 5:5
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 7:7
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 9:9
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 11:11
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;

for elecOrder = 4:4
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 6:6
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 8:8
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 10:10
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 12:12
    [Pxx,f] = pwelch(Data(elecOrder,:),winlen,128,winlen,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
% Ratio = sum(Right_Hand)/sum(Left_Hand);
h = figure;
subplot(1,2,1);
plot(f, Right_Hand,'b','linewidth',2);
hold on
plot(f, Left_Hand,'r','linewidth',2);
axis([0 50 0 1.2*max(max([Right_Hand,Left_Hand]))]);
legend('Left Brain','Right Brain');
axis('square');
bandLimit = [low_c,high_c];

for elecOrder = 1:size(Data,1)
    [Pxx,f] = pwelch(Data(elecOrder,:),128,32,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    Power(elecOrder,1) = mean(Pxx(ind1:ind2,1));
end
subplot(1,2,2);
topoplot(Power(:,1),'newspline15_clI.loc',...
    'maplimits','maxmin','style','both',...
    'electrodes','ptslabels','plotrad',0.511,'efontsize',9);
TitleName = [int2str(low_c),'Hz-',int2str(high_c),'Hz'];
title(TitleName);

fileName = [FilePath_Brain_Topo '.jpg'];
saveas(h,fileName);
% fileName_2 = [FilePath_Brain_Topo '.fig'];
% saveas(h,fileName_2);
close(h);
end