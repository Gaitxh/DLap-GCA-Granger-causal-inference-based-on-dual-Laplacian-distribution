function Data = Data_Preprocess(Data,low_c,high_c,case_Num,Fs,downSmaple,filterorder)
if rank(Data)~=size(Data,1)
    [U,S,V] = svd(Data);
    add_value = mean(diag(S))/20;
    for c_i = 1:size(Data,1)
        S(c_i,c_i) = S(c_i,c_i) + add_value;
    end
    Data = U*S*V';
end
Data = Data_detrend(Data);
Data = Data_demean(Data);
switch case_Num
    case 1
        max_order = filterorder;
        Data = Data_Filter(Data,low_c, high_c,max_order,Fs);
    case 2
        %Chebyshev_II_LowPass_Filter
        max_order = 10;
        LowPassValue = max([low_c,high_c]);
        for c_i = 1:size(Data,1)
            Data(c_i,:) = Chebyshev_II_LowPass_Filter(Data(c_i,:), max_order, LowPassValue, 50, Fs);
        end
    case 3
        % Butterworth_bandpass Filter
        max_order = 3;
        for c_i = 1:size(Data,1)
            Data(c_i,:) = Butterworth_Filter(Data(c_i,:),Fs, max_order,low_c,high_c);
        end
end

for c_i = 1:size(Data,1)
    Data_D(c_i,:) = downsample(Data(c_i,:),downSmaple);
end
Data = Data_D;
end