function Data_Filter = Notch_Filter(Data,Fs,Hz)
% f0:�ݲ�Ƶ��
% fs:����Ƶ��
for channel_ii = 1:1:size(Data,1)
    f0=Hz;fs=Fs;r=0.9;
    w0=2*pi*f0/fs;
    b=[1 -2*cos(w0) 1];
    a=[1 -2*r*cos(w0) r*r];
    N=size(Data(channel_ii,:),2);
    [H,w]=freqz(b,a,N);
    n=0:N-1;
    x=Data(channel_ii,:);
    X=fft(x,N);
    Data_Filter(channel_ii,:)=filter(b,a,x);
    Y=fft(Data_Filter(channel_ii,:),N);
    f=fs/N*(0:N/2-1);
    % figure;
    % subplot(221);plot(n,x);grid on;title('ԭ�ź�x(n)');
    % subplot(222);plot(f,abs(X(1:N/2)));grid on;title('x(n)�ķ�Ƶ��');
    % subplot(223);plot(n,y);grid on;title('�ݲ����˲�����ź�y(n)');
    % subplot(224);plot(f,abs(Y(1:N/2)));grid on;title('y(n)�ķ�Ƶ��');
end


end

