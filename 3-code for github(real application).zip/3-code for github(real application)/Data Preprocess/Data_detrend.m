function [Y]=Data_detrend(X)

nobs = size(X,2);
nvar = size(X,1);
if(nvar>nobs) error('error in cca_detrend: nvar>nobs, check input matrix'); end

X = X';
Y = detrend(X);  % use inbuilt detrend function
Y = Y';
