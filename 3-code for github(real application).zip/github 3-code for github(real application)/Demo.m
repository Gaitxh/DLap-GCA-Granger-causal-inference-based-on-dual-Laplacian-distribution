clc;
clear all;
close all;
addpath(genpath(pwd))
Basic_Path = [pwd,'\'];
DataSavePath = [Basic_Path,'Running Data\'];%%Segment the data and place it in this folder
FileName_Brain_pole = [Basic_Path,'newspline15_clI.loc'];%%The coordinates file for 15 channels
ChannelOrder=[6,36,10,40,15,44,16,45,19 ,49,24,53,30,59,13];
%%F3 F4 FC3 FC4 C3 C4 C5 C6 CP3 CP4 P3 P4 O1 O2 CZ
Method_flag = [1,2,3,4,5];
Method_Label = {'LS','Gau','Lap','GLap','DLap'};
FileName = dir(fullfile(DataSavePath,'*.mat'));%%The code will iterate through all .mat data files in the folder.
begin_File = 1;Intervalue = 1;
for File_ii = begin_File:Intervalue:size(FileName,1)
    load(FileName(File_ii).name);%%The code will read each data file name one by one and load the corresponding file.
    SaveName = FileName(File_ii).name;
    Fs = 1000;
    Data = Data(:,.5*Fs+1:2.5*Fs);%%Data segment selection, where 0.5-2.5 seconds after prompt is selected for subsequent analysis; Of course, you can also define it yourself
    Fs = 1000;%%sampling rate
    low_c = 2;high_c = 30;%%Bandpass filtering range setting
    case_Num = 1;%%Filter type, 1 represents the filter in the eeglab
    downSmaple = 1;%%Downsampling multiple
    filterorder = 60;%%filter order "We strongly recommend ensuring that the filtering is effective here"
    Data = Data_Preprocess(Data,low_c,high_c,case_Num,Fs,downSmaple,filterorder);
    Fs = Fs/downSmaple;
    %%This section pertains to the selection of model order, which you can implement according to your specific needs. There are primarily two main approaches for model order 
    %%selection:1.Fixed Model Order Based on Previous Experience: You can choose a fixed model order based on prior knowledge and experience.2.Model Order Determination Using BIC or AIC 
    %%Criteria: We strongly recommend using the Bayesian Information Criterion (BIC) to determine the model order for each subject. It is advisable to compute the maximum model order 
    %%across all data segments within the current subject, rather than for each individual data segment. This approach enhances the generalizability of the model."
    NLAGS = 11;
    %%or choice
    [NLAGS,~] = cca_find_model_order(Data,2,11);
    for method_ii = 1:length(Method_flag)
        fileretpath = [Basic_Path,'our Net Result ',int2str(low_c),'-',int2str(high_c),'Hz'];
        warning off;mkdir([fileretpath]);
        tic
        ret = Net_Estimate(Data,Method_flag(method_ii),NLAGS);
        ret.p = NLAGS;
        ret.Label = str2num(SaveName(end-4));
        T = toc;
        fprintf('File_: %d, Method: %s, Spend Time: %.2f s\n',File_ii,Method_Label{Method_flag(method_ii)},T);
        save([fileretpath,'\',SaveName(1:end-4),'-',Method_Label{Method_flag(method_ii)},'.mat'],'ret');
    end
end