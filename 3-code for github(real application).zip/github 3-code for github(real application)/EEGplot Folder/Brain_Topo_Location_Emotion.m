function [Ratio] = Brain_Topo_Location_Emotion(Data,FilePath_Brain_Topo,Fs,low_c,high_c)
bandLimit = [low_c,high_c];

Right_Hand = 0;Left_Hand = 0;
for elecOrder = 3:3
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 5:5
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 7:7
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 9:9
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;
for elecOrder = 11:11
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Right_Hand = Right_Hand + Pxx;

for elecOrder = 4:4
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 6:6
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 8:8
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 10:10
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
for elecOrder = 12:12
    [Pxx,f] = pwelch(Data(elecOrder,:),128,64,128,Fs);
    ind1 = find(f>=bandLimit(1,1),1,'first');
    ind2 = find(f>=bandLimit(1,2),1,'first');
    %Pxx = Standard_Normalization(Pxx);
end
Left_Hand = Left_Hand + Pxx;
% Ratio = sum(Right_Hand)/sum(Left_Hand);
h = figure;
plot(f, Right_Hand,'b','linewidth',2);
hold on
plot(f, Left_Hand,'r','linewidth',2);
axis([0 50 0 1.2*max(max([Right_Hand,Left_Hand]))]);
legend('Right_Hand','Left_Hand');
fileName = [FilePath_Brain_Topo '.jpg'];
saveas(h,fileName);
% fileName_2 = [FilePath_Brain_Topo '.fig'];
% saveas(h,fileName_2);
close(h);
end

function Data = Standard_Normalization(Data)
for data_ii = 1:1:size(Data,2)
    max_value = max(Data(:,data_ii));
    min_value = min(Data(:,data_ii));
    Data(:,data_ii) = (Data(:,data_ii)-min_value)./(max_value-min_value);
end
end