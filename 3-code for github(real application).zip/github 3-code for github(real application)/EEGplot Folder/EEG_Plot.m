function EEG_Plot(Data_filter,EEGDatapath_untreated)
h= figure('color',[1 1 1]);
Pic_Flag = [12,14,27,31,43,47,42,48,59,63,75,79,92,94,45];
Channel_Label = {'F3','F4','FC3','FC4','C3','C4','C5','C6','CP3','CP4','P3','P4','O1','O2','Cz'};
for channel_ii = 1:1:size(Data_filter)
    subplot(10,16,Pic_Flag(channel_ii));
    plot(Data_filter(channel_ii,:),'b','linewidth',1);
    axis([0 size(Data_filter,2) min(Data_filter(channel_ii,:)) max(Data_filter(channel_ii,:))]);
    set(gca,'linewidth',2);
    set(gca,'xtick',[]);
    set(gca,'ytick',[]);
    %     set(gcf,'color','none');
    set(gca,'color','none');
    y=ylabel(Channel_Label{channel_ii},'FontSize',24,'FontName','Times New Roman','FontWeight','bold','FontSize',12, 'rot', 0);
    if Pic_Flag(channel_ii) == 27||Pic_Flag(channel_ii) == 31||Pic_Flag(channel_ii) == 59||Pic_Flag(channel_ii) == 63
        set(y, 'Units', 'Normalized', 'Position', [-0.29, 0.4, 0]);
    else
        set(y, 'Units', 'Normalized', 'Position', [-0.2, 0.4, 0]);
    end
    box off
end
%     set(gca,'FontSize',24,'FontName','Times New Roman','FontWeight','bold');

subplot(10,16,[33 152]);
plot(Data_filter(2,:),'b','linewidth',2);
axis([0 length(Data_filter(2,:)) min(Data_filter(2,:)) max(Data_filter(2,:))]);
xlabel('Time/ms','FontSize',24,'FontName','Times New Roman','FontWeight','bold');
ylabel('Amplitude/uv','FontSize',24,'FontName','Times New Roman','FontWeight','bold');
set(gca,'linewidth',1.5);
box off
set(gcf,'unit','centimeters','position',[0 0 30 15]);
fileName = [EEGDatapath_untreated, '.jpg'];
saveas(h,fileName);
close(h);
end