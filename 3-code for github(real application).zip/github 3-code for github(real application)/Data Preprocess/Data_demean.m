function [X2,m,e] = Data_demean(X,FLAG)

[nvar nobs] = size(X);
if(nobs < nvar) 
    error('error in cca_rm_temporalmean: nobs < nvar, check data matrix');
end
if  nargin < 2,
    FLAG = 0;
end
clear m;
e = [];
for ii=1:nvar,
    vec = X(ii,:);
    m(ii) = mean(vec);
    vec = vec-m(ii);
    X(ii,:) = vec;
    if FLAG == 1,   % divide by temporal std if required
        e(ii) = std(vec);
        X(ii,:) = X(ii,:)./e(ii);
    end
end
X2 = X;



