function Data = Data_Filter(Data,low_c, high_c,max_order,Fs)
        FreBand = [low_c, high_c];
        if 3*Fs/(min(FreBand)) > max_order
            filter_order = max_order;
        else
            filter_order = floor(3*Fs/(min(FreBand)));
        end
        Data = eegfilt(Data,Fs,FreBand(1),FreBand(2), 0, filter_order);
end