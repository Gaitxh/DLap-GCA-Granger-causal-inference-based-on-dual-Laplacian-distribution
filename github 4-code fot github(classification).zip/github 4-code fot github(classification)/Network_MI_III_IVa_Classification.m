clc;
clear all;
close all;
addpath(genpath(pwd))
%%F3 F4 FC3 FC4 C3 C4 C5 C6 CP3 CP4 P3 P4 O1 O2 CZ
Method_flag = [1,2,3,4];
Method_Label = {'Gau','Lap','GLap','DLap'};

for method_ii = 1:length(Method_flag)
    for File_ii = 1:5
        
        load(['III IVa net-feature sub-',int2str(File_ii),'.mat']);
        MI_feature = feature_net{method_ii};
        MI_feature([1:15:225],:) = [];
        count = 0;
        iterationNum = 10;
        for iter_i = 1:iterationNum
            Indices =crossvalind('Kfold', length(Label)/2, iterationNum);
            label_type = unique(Label);
            loc_label1 = find(Label == label_type(1));
            loc_label2 = find(Label == label_type(2));
            for sub_i = 1:length(unique(Indices))
                test_loc = find(Indices==sub_i);
                test_loc = [loc_label1(test_loc),loc_label2(test_loc)];
                train_loc = setdiff(1:length(Label),test_loc);
                Label_Test = Label(test_loc);Data_Test = MI_feature(:,test_loc);
                Label_Train = Label(train_loc);Data_Train = MI_feature(:,train_loc);
                
                Train_Feature = Data_Train';
                Test_Feature = Data_Test';
                model = svmtrain(Label_Train',Train_Feature,'-t 0');
                [predicted_label, accuracy, prob_estimates] = svmpredict(Label_Test',Test_Feature, model);
                
                count = count + 1;
                Classification_R(count) = accuracy(1);
            end
        end
        clear MI_feature
        mean_ClassAccuracy(File_ii,method_ii) = mean(Classification_R);
        std_ClassAccuracy(File_ii,method_ii) = std(Classification_R);
    end
end